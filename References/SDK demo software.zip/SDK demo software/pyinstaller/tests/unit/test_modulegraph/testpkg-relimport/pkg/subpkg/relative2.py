""" pkg.subpkg.relative """
from __future__ import absolute_import
from ..relimport import __doc__ as doc
