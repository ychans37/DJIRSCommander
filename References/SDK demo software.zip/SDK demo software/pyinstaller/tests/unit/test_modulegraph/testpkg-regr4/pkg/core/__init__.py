""" pkg.core.__init__ """
