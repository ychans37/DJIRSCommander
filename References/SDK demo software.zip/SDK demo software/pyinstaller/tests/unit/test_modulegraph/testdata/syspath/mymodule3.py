"""  fake module """
