from setuptools import setup

setup(
        name="namedpkg",
        version="1.0",
        packages=["namedpkg"],
        namespace_packages=["namedpkg"],
)
